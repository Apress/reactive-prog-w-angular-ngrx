/* tslint:disable */
export let YoutubeMediaMock = {
  "kind": "youtube#searchResult",
  "etag": "\"q5k97EMVGxODeKcDgp8gnMu79wM/ms1isEChRlNREE1F9UOkqY3Ihe8\"",
  "id": {
    "kind": "youtube#video",
    "videoId": "5PGvyjZtVKU"
  },
  "snippet": {
    "publishedAt": "2016-02-19T15:00:39.000Z",
    "channelId": "UCRxLFt-qJHbT-zzeZt4eQpw",
    "title": "TREMONTI + DUST = 04.29.16",
    "description": "\"Dust\" Presale Available NOW - https://fret12.com/store/tremonti-dust 'Dust' is Tremonti's follow up record to their 2015 FRET12 release 'Cauterize'. Get all the ...",
    "thumbnails": {
      "default": {
        "url": "https://i.ytimg.com/vi/5PGvyjZtVKU/default.jpg",
        "width": 120,
        "height": 90
      },
      "medium": {
        "url": "https://i.ytimg.com/vi/5PGvyjZtVKU/mqdefault.jpg",
        "width": 320,
        "height": 180
      },
      "high": {
        "url": "https://i.ytimg.com/vi/5PGvyjZtVKU/hqdefault.jpg",
        "width": 480,
        "height": 360
      }
    },
    "channelTitle": "TremontiOfficial",
    "liveBroadcastContent": "none"
  }
}
