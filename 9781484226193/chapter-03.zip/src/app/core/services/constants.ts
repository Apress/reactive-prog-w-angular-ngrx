export const YOUTUBE_API_KEY: string = 'AIzaSyCVYIw6U-DRioMSJ2ZUm0H3kdQyR_D6oQk';
export const CLIENT_ID: string = '971861197531-i7h00h6789mkievtthgn6qoommbs76ih';
